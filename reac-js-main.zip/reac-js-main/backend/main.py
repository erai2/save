from __future__ import annotations

from typing import List, Optional
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from starlette.responses import StreamingResponse
import io
import csv
import time
import os
import io
import json

app = FastAPI(title="HCJ API", version="1.0.0")

# CORS: 프론트(vite dev, streamlit)와 개발 호스트 모두 허용
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class Rule(BaseModel):
    id: int = Field(..., description="unique rule id")
    condition: str
    action: str


# 데모용 인메모리 저장
_rules: List[Rule] = [
    Rule(id=1, condition="text contains 'error'", action="label='issue'"),
    Rule(id=2, condition="score > 0.9", action="route='priority'"),
]


@app.get("/health")
def health():
    return {"status": "ok", "ts": int(time.time())}


@app.get("/rules", response_model=List[Rule])
def list_rules():
    return _rules


@app.get("/rules/{rule_id}", response_model=Rule)
def get_rule(rule_id: int):
    for r in _rules:
        if r.id == rule_id:
            return r
    raise HTTPException(status_code=404, detail="Rule not found")


@app.post("/rules", response_model=Rule, status_code=201)
def add_rule(rule: Rule):
    if any(r.id == rule.id for r in _rules):
        raise HTTPException(status_code=409, detail="Duplicate id")
    _rules.append(rule)
    return rule


@app.put("/rules/{rule_id}", response_model=Rule)
def edit_rule(rule_id: int, rule: Rule):
    for i, r in enumerate(_rules):
        if r.id == rule_id:
            _rules[i] = rule
            return rule
    raise HTTPException(status_code=404, detail="Rule not found")


@app.delete("/rules/{rule_id}", status_code=204)
def delete_rule(rule_id: int):
    for i, r in enumerate(_rules):
        if r.id == rule_id:
            _rules.pop(i)
            return
    raise HTTPException(status_code=404, detail="Rule not found")


@app.post("/upload-file")
async def upload_file(file: UploadFile = File(...)):
    """
    범용 파일 업로드: txt, md, json, docx 등 미리보기 제공.
    저장하지 않고 메모리에서 처리.
    """
    info = {
        "filename": file.filename,
        "content_type": file.content_type,
        "size_bytes": 0,
        "preview": None,
        "preview_type": None,  # text / json / none / error
    }

    content = await file.read()
    info["size_bytes"] = len(content)
    ext = os.path.splitext(file.filename)[1].lower()

    # 기본 UTF-8 텍스트 디코딩 시도(텍스트 류에만 적용)
    def try_decode_text(b: bytes, limit: int = 200) -> str | None:
        try:
            return b.decode("utf-8", errors="replace")[:limit]
        except Exception:
            return None

    if ext in (".txt", ".md"):
        info["preview"] = try_decode_text(content)
        info["preview_type"] = "text" if info["preview"] is not None else "error"

    elif ext == ".json":
        try:
            data = json.loads(content.decode("utf-8"))
            # 보기 좋게 200자 정도 슬라이스
            compact = json.dumps(data, ensure_ascii=False)
            info["preview"] = compact[:200]
            info["preview_type"] = "json"
        except Exception:
            info["preview"] = "JSON 파싱 실패"
            info["preview_type"] = "error"

    elif ext == ".docx":
        try:
            from docx import Document  # lazy import
            doc = Document(io.BytesIO(content))
            text = "\n".join([p.text for p in doc.paragraphs])
            info["preview"] = text[:200] if text else "(빈 문서)"
            info["preview_type"] = "text"
        except Exception:
            info["preview"] = "DOCX 읽기 실패"
            info["preview_type"] = "error"

    else:
        # 기타 형식은 미리보기 생략
        info["preview"] = "미리보기 없음"
        info["preview_type"] = "none"

    return info


@app.get("/export")
def export_rules_csv():
    # CSV 스트림으로 내보내기
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=["id", "condition", "action"])
    writer.writeheader()
    for r in _rules:
        writer.writerow(r.model_dump())
    buf.seek(0)
    return StreamingResponse(
        io.BytesIO(buf.getvalue().encode("utf-8")),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="rules.csv"'},
    )
