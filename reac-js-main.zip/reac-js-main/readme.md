fuc/
├─ backend/
│  ├─ app.py
│  ├─ db.py
│  ├─ models.py
│  ├─ schemas.py
│  ├─ seed.py
│  ├─ requirements.txt
│  └─ Dockerfile
├─ frontend/
│  ├─ index.html
│  ├─ package.json
│  ├─ vite.config.js
│  └─ src/
│     ├─ main.jsx
│     ├─ App.jsx
│     ├─ api.js
│     ├─ components/
│     │  ├─ Controls.jsx
│     │  ├─ SummaryChart.jsx
│     │  └─ DataTable.jsx
│     └─ styles.css
├─ docker-compose.yml
└─ Makefile
