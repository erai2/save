from __future__ import annotations
from typing import Dict, Iterable, List, Sequence, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

def extract_cluster_keywords(
    texts: Sequence[str],
    labels: Sequence[int],
    top_n: int = 5,
    *,
    stop_words: str | Iterable[str] | None = "english",
    ngram_range: Tuple[int, int] = (1, 2),
    min_df: int | float = 2,
    max_features: int | None = 20000,
) -> Dict[int, List[str]]:
    if len(texts) == 0:
        return {}
    if len(texts) != len(labels):
        raise ValueError("texts와 labels 길이가 다릅니다.")
    vec = TfidfVectorizer(
        stop_words=stop_words, ngram_range=ngram_range,
        min_df=min_df, max_features=max_features
    )
    X = vec.fit_transform(texts)
    vocab = vec.get_feature_names_out()
    labels = np.asarray(labels)
    result: Dict[int, List[str]] = {}
    for cid in sorted(np.unique(labels)):
        mask = labels == cid
        if not np.any(mask):
            result[int(cid)] = []
            continue
        mean_vec = X[mask].mean(axis=0).A1
        top_idx = np.argsort(mean_vec)[::-1][:top_n]
        result[int(cid)] = [vocab[i] for i in top_idx if mean_vec[i] > 0]
    return result
