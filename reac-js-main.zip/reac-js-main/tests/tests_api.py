import requests
import time

BASE = "http://localhost:8000"

def wait_up():
    for _ in range(20):
        try:
            r = requests.get(f"{BASE}/health", timeout=1)
            if r.status_code == 200:
                return True
        except Exception:
            time.sleep(0.2)
    return False

def test_health():
    assert wait_up()
    r = requests.get(f"{BASE}/health")
    assert r.status_code == 200
    assert r.json().get("status") == "ok"

# tests_api.py (추가)
def test_upload_file_txt():
    import io, requests
    content = b"hello world"
    files = {"file": ("test.txt", io.BytesIO(content), "text/plain")}
    r = requests.post(f"{BASE}/upload-file", files=files, timeout=5)
    assert r.status_code == 200
    j = r.json()
    assert j["filename"] == "test.txt"
    assert j["size_bytes"] == len(content)
    assert j["preview_type"] in ("text", "none")
