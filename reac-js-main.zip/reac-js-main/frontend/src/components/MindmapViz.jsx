export default function MindmapViz({ rules }) {
  return (
    <div className="text-gray-600">
      Mindmap visualization is not implemented yet.
    </div>
  );
}
