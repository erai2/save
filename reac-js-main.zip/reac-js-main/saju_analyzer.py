from __future__ import annotations
from typing import Dict, Any


def analyze_saju(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    사주 데이터를 분석해서 결과를 반환합니다.
    """
    year = data.get("year")
    month = data.get("month")
    day = data.get("day")
    hour = data.get("hour")

    element = _get_element_from_year(year) if year else "Unknown"

    return {
        "input": data,
        "summary": f"{year}년생, 오행은 {element} 중심",
        "elements": {
            "year_element": element,
            "fortune": "좋음" if (month and month in (3, 4, 5)) else "보통",
        }
    }


def _get_element_from_year(year: int) -> str:
    """년도에 따른 오행(목·화·토·금·수) 계산 예시"""
    elements = ["목", "목", "화", "화", "토", "토", "금", "금", "수", "수"]
    if not year:
        return "Unknown"
    return elements[(year % 10)]


if __name__ == "__main__":
    sample_data = {"year": 1990, "month": 5, "day": 21, "hour": 15}
    print(analyze_saju(sample_data))
