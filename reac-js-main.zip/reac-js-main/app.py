import streamlit as st
import requests
import streamlit as st
from saju_analyzer import analyze_saju

st.set_page_config(page_title="HCJ Streamlit", layout="centered")
st.title("HCJ Streamlit")

api_base = st.text_input("API Base URL", value="http://localhost:8000")
st.caption("FastAPI 서버를 별도로 띄우지 않아도 아래 '로컬 처리' 데모는 동작합니다.")

st.header("Rules (via API)")
if st.button("Health check"):
    try:
        r = requests.get(f"{api_base}/health", timeout=5)
        st.write(r.json())
    except Exception as e:
        st.error(str(e))

with st.form("add_rule"):
    col1, col2, col3 = st.columns(3)
    with col1:
        rid = st.number_input("id", min_value=1, step=1)
    with col2:
        cond = st.text_input("condition")
    with col3:
        action = st.text_input("action")
    submitted = st.form_submit_button("Add")
    if submitted:
        try:
            r = requests.post(f"{api_base}/rules", json={"id": rid, "condition": cond, "action": action})
            st.success(r.json())
        except Exception as e:
            st.error(str(e))

if st.button("List rules"):
    try:
        r = requests.get(f"{api_base}/rules")
        st.table(r.json())
    except Exception as e:
        st.error(str(e))

st.header("구조 분석 (로컬 실행)")
year = st.number_input("출생 연도", min_value=1900, max_value=2100, value=1990)
month = st.number_input("월", 1, 12, 5)
day = st.number_input("일", 1, 31, 21)
hour = st.number_input("시", 0, 23, 15)

if st.button("분석하기"):
    result = analyze_saju({"year": year, "month": month, "day": day, "hour": hour})
    st.json(result)