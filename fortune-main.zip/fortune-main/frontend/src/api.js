// Placeholder for API helper functions
export async function getTerms() {
  // Implementation will be added later
  return [];
}
