import React from 'react';

function App() {
  return <div>App component</div>;
}

export default App;
