import React from 'react';

function TermCardList() {
  return <div>TermCardList component</div>;
}

export default TermCardList;
