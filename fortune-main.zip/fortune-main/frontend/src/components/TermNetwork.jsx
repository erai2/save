import React from 'react';

function TermNetwork() {
  return <div>TermNetwork component</div>;
}

export default TermNetwork;
