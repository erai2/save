import React from 'react';

function TermTree() {
  return <div>TermTree component</div>;
}

export default TermTree;
