import React from 'react';

function TermForm() {
  return <div>TermForm component</div>;
}

export default TermForm;
