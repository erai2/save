import React from 'react';

function SearchBox() {
  return <div>SearchBox component</div>;
}

export default SearchBox;
