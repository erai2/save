import React from 'react';

function TermDetail() {
  return <div>TermDetail component</div>;
}

export default TermDetail;
