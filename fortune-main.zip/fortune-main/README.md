# Fortune Streamlit App

This repository contains a Streamlit application for exploring case data and visualising keyword networks.

## Running locally

1. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

2. Start the application:

   ```bash
   streamlit run main.py
   ```

The app expects a JSON file at `DEFAULT_JSON` (`/mnt/data/suam_cases_parsed_v2.json` by default). Update the path in `main.py` or upload your own JSON through the sidebar.

## Docker

To run inside Docker:

```bash
docker build -t fortune-app .
docker run -p 8501:8501 fortune-app
```
