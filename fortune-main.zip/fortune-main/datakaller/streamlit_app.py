#!/usr/bin/env python
import streamlit as st
import requests
import pandas as pd
import io
import time
import os

# 백엔드 API 주소 (도커 컴포즈 내에선 http://api:8000, 로컬 실행 시엔 http://localhost:8000)
API_BASE = os.environ.get("API_BASE", "http://localhost:8000")

st.set_page_config(page_title="Databox Streamlit", layout="wide")
st.title("📦 Databox — 문서 업로드 · 추출 · 시각화")

# -----------------------------------------------------------------------------
# 유틸
# -----------------------------------------------------------------------------
def api_get(path, **kwargs):
    r = requests.get(f"{API_BASE}{path}", timeout=60, **kwargs)
    r.raise_for_status()
    return r.json()

def api_post(path, json=None, files=None, data=None):
    r = requests.post(f"{API_BASE}{path}", json=json, files=files, data=data, timeout=3600)
    r.raise_for_status()
    return r.json()

def health_block():
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("API Health"):
            try:
                h = api_get("/health")
                st.success(h)
            except Exception as e:
                st.error(f"Health 실패: {e}")
    with col2:
        if st.button("INIT SQL 재적용"):
            try:
                res = api_post("/init")
                st.success(res)
            except Exception as e:
                st.error(f"INIT 실패: {e}")
    with col3:
        if st.button("Passages CSV Export"):
            try:
                r = requests.get(f"{API_BASE}/export/passages.csv", timeout=120)
                r.raise_for_status()
                st.download_button("passages.csv 다운로드", r.content, "passages.csv", "text/csv")
            except Exception as e:
                st.error(f"Export 실패: {e}")

# -----------------------------------------------------------------------------
# 업로드 & Ingest
# -----------------------------------------------------------------------------
st.subheader("📤 문서 업로드 & Ingest")

with st.form("upload_form"):
    uploaded = st.file_uploader("문서를 업로드하세요 (여러 파일/ZIP 가능)", type=None, accept_multiple_files=True)
    subdir = st.text_input("저장 하위 폴더 (uploads/ 아래)", value="my_docs")
    extract_zip = st.checkbox("ZIP 자동 해제", value=True)
    batch_size = st.number_input("batch_size", min_value=1, value=200, step=50)
    max_len = st.number_input("max_len", min_value=100, value=1200, step=100)

    c1, c2 = st.columns(2)
    with c1:
        do_upload = st.form_submit_button("업로드만")
    with c2:
        do_upload_ingest = st.form_submit_button("업로드 후 Ingest")

if do_upload or do_upload_ingest:
    if not uploaded:
        st.warning("업로드할 파일을 선택하세요.")
    else:
        try:
            files = [('files', (f.name, f.getvalue())) for f in uploaded]
            if do_upload:
                res = api_post("/upload", files=files, data={
                    "subdir": subdir, "extract_zip": str(extract_zip).lower()
                })
                st.success(res)
            else:
                with st.spinner("업로드 및 Ingest 실행 중..."):
                    res = api_post("/upload-and-ingest", files=files, data={
                        "subdir": subdir,
                        "extract_zip": str(extract_zip).lower(),
                        "batch_size": str(batch_size),
                        "max_len": str(max_len)
                    })
                st.success({"rc": res.get("rc"), "saved": res.get("saved"), "ingest_path": res.get("ingest_path")})
                st.expander("stdout / stderr").write({"stdout": res.get("stdout"), "stderr": res.get("stderr")})
        except Exception as e:
            st.error(f"업로드/ingest 실패: {e}")

# -----------------------------------------------------------------------------
# 파이프라인 실행 (Jobs)
# -----------------------------------------------------------------------------
st.subheader("⚙️ 데이터 파이프라인 실행")
job_cols = st.columns(6)
jobs = ["ingest_chunks", "extract_terms", "semantic_labeler", "apply_rules", "embed_update", "load_and_classify"]

for i, j in enumerate(jobs):
    if job_cols[i].button(j):
        try:
            with st.spinner(f"{j} 실행 중..."):
                res = api_post("/jobs/run", json={"name": j, "params": {}})
            st.success({"rc": res.get("rc")})
            st.expander(f"{j} - 출력 보기").write({"stdout": res.get("stdout"), "stderr": res.get("stderr")})
        except Exception as e:
            st.error(f"{j} 실패: {e}")

# -----------------------------------------------------------------------------
# DB 요약 시각화
# -----------------------------------------------------------------------------
st.subheader("📊 DB 요약")
try:
    stats = api_get("/stats")
    counts = stats.get("counts", {})
    df_counts = pd.DataFrame([{"table": k, "count": v} for k, v in counts.items()])
    if len(df_counts):
        st.dataframe(df_counts, use_container_width=True)
        try:
            import plotly.express as px
            st.plotly_chart(px.bar(df_counts, x="table", y="count", title="테이블별 행 수"), use_container_width=True)
        except Exception:
            st.info("Plotly가 설치되지 않았습니다. (requirements.streamlit.txt에 plotly 추가 가능)")
    else:
        st.info("표시할 통계가 없습니다.")
except Exception as e:
    st.error(f"/stats 조회 실패: {e}")

# -----------------------------------------------------------------------------
# 라벨 청크/용어 조회 (존재 시)
# -----------------------------------------------------------------------------
st.subheader("🔎 라벨 청크 & 용어 사전 (선택)")
with st.expander("라벨 청크 조회"):
    name = st.text_input("라벨 이름", value="응기_출현")
    min_score = st.number_input("min_score", value=0.0, step=0.1)
    limit = st.number_input("limit", value=50, step=10)
    if st.button("라벨 청크 가져오기"):
        try:
            # 기존 프로젝트에 /label/chunks 가 있을 때
            r = requests.get(f"{API_BASE}/label/chunks", params={"name": name, "min_score": min_score, "limit": limit}, timeout=120)
            r.raise_for_status()
            data = r.json()
            if isinstance(data, list) and data:
                st.dataframe(pd.DataFrame(data), use_container_width=True, height=320)
            else:
                st.info("데이터 없음")
        except Exception as e:
            st.error(f"/label/chunks 조회 실패 또는 엔드포인트 없음: {e}")

with st.expander("용어 사전 검색"):
    term = st.text_input("term", value="응기")
    if st.button("검색"):
        try:
            r = requests.get(f"{API_BASE}/terms/{term}", timeout=120)
            r.raise_for_status()
            data = r.json()
            if isinstance(data, list) and data:
                st.dataframe(pd.DataFrame(data), use_container_width=True, height=320)
            else:
                st.info("결과 없음")
        except Exception as e:
            st.error(f"/terms/{term} 조회 실패 또는 엔드포인트 없음: {e}")

# -----------------------------------------------------------------------------
# 하단 유틸
# -----------------------------------------------------------------------------
st.divider()
health_block()
st.caption(f"API_BASE = {API_BASE}")