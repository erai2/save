import React, { useState } from 'react'

const rowStyle = { display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }

export default function Jobs({ onRun, last }) {
  const [params, setParams] = useState({
    path: './corpus', batch_size: 200, max_len: 1200,
    min_conf: 0.5,
    min_score: 0.5, limit: 0, dry_run: false,
    batch_size_emb: 128, limit_cases: 0, no_normalize: false,
  })
  const upd = (k,v)=>setParams(p=>({...p,[k]:v}))

  return (
    <div className="card">
      <strong>📦 데이터 파이프라인 실행</strong>
      <div className="btns" style={{ marginTop:8 }}>
        <button onClick={()=>onRun('ingest_chunks', { path: params.path, batch_size: params.batch_size, max_len: params.max_len })}>ingest_chunks</button>
        <button onClick={()=>onRun('extract_terms', { min_conf: params.min_conf })}>extract_terms</button>
        <button onClick={()=>onRun('semantic_labeler', {})}>semantic_labeler</button>
        <button onClick={()=>onRun('apply_rules', { min_score: params.min_score, limit: params.limit, dry: params.dry_run ? '1':undefined })}>apply_rules</button>
        <button onClick={()=>onRun('embed_update', { batch_size: params.batch_size_emb, limit_cases: params.limit_cases, no_normalize: params.no_normalize ? '1': undefined })}>embed_update</button>
        <button onClick={()=>onRun('load_and_classify', {})}>load_and_classify</button>
      </div>
      <div style={{ marginTop:12, ...rowStyle }}>
        <label>경로 <input value={params.path} onChange={e=>upd('path', e.target.value)} /></label>
        <label>Batch <input type="number" value={params.batch_size} onChange={e=>upd('batch_size', parseInt(e.target.value||0))} /></label>
        <label>MaxLen <input type="number" value={params.max_len} onChange={e=>upd('max_len', parseInt(e.target.value||0))} /></label>
        <label>min_conf <input type="number" step="0.01" value={params.min_conf} onChange={e=>upd('min_conf', e.target.value)} /></label>
        <label>min_score <input type="number" step="0.01" value={params.min_score} onChange={e=>upd('min_score', e.target.value)} /></label>
        <label>limit <input type="number" value={params.limit} onChange={e=>upd('limit', parseInt(e.target.value||0))} /></label>
        <label><input type="checkbox" checked={params.dry_run} onChange={e=>upd('dry_run', e.target.checked)} /> dry-run</label>
        <label>emb batch <input type="number" value={params.batch_size_emb} onChange={e=>upd('batch_size_emb', parseInt(e.target.value||0))} /></label>
        <label>limit_cases <input type="number" value={params.limit_cases} onChange={e=>upd('limit_cases', parseInt(e.target.value||0))} /></label>
        <label><input type="checkbox" checked={params.no_normalize} onChange={e=>upd('no_normalize', e.target.checked)} /> no-normalize</label>
      </div>
      {last && (
        <div style={{ marginTop:12 }}>
          <div className="badge">마지막 실행</div>
          <pre style={{ marginTop:8, background:'#0b1220', border:'1px solid #1e293b', borderRadius:8, padding:12, maxHeight:260, overflow:'auto' }}>
{last.stdout || '(출력 없음)'}
{last.stderr ? '\n[stderr]\n'+last.stderr : ''}
          </pre>
        </div>
      )}
    </div>
  )
}
