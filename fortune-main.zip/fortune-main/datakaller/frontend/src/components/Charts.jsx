import React, { useEffect, useRef } from 'react'

export function BarChart({ data=[], title='Chart' }) {
  const ref = useRef(null)
  useEffect(()=>{
    const c=ref.current, ctx=c.getContext('2d')
    const w=c.width=c.clientWidth, h=c.height=c.clientHeight
    ctx.clearRect(0,0,w,h)
    ctx.fillStyle='white'; ctx.font='14px sans-serif'; ctx.fillText(title, 12, 20)
    if (!data.length){ ctx.fillStyle='#94a3b8'; ctx.fillText('데이터 없음', 12, 44); return }
    const pad=36, max=Math.max(...data.map(d=>d.v))||1
    const step=(w-pad*2)/data.length
    ctx.strokeStyle='#1f2937'; ctx.beginPath(); ctx.moveTo(pad,h-pad); ctx.lineTo(w-pad,h-pad); ctx.stroke()
    data.forEach((d,i)=>{
      const x=pad+i*step+step*0.15, bw=step*0.7, bh=(h-pad*2)*d.v/max
      ctx.fillStyle='#60a5fa'; ctx.fillRect(x,h-pad-bh,bw,bh)
      ctx.fillStyle='#9ca3af'; ctx.font='12px sans-serif'
      const lbl=d.k.length>10?d.k.slice(0,10)+'…':d.k
      ctx.fillText(lbl,x,h-8)
    })
  },[data,title])
  return <canvas className="chart" ref={ref}/>
}
