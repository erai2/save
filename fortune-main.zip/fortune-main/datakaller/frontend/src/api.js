const api = {
  health(){ return fetch('/api/health').then(r=>r.json()) },
  stats(){ return fetch('/api/stats').then(r=>r.json()) },
  init(){ return fetch('/api/init', { method:'POST' }).then(r=>r.json()) },
  exportPassages(){
    return fetch('/api/export/passages.csv')
    .then(r=>r.blob()).then(b=>{
      const url=URL.createObjectURL(b); const a=document.createElement('a')
      a.href=url; a.download='passages.csv'; a.click(); URL.revokeObjectURL(url)
    })
  },
  runJob(name, params={}){
    return fetch('/api/jobs/run', {
      method:'POST',
      headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify({ name, params })
    }).then(r=>r.json())
  },
  labelChunks({ name, min_score=0.5, limit=200 }){
    const q=new URLSearchParams({ name, min_score, limit })
    return fetch('/api/label/chunks?'+q).then(r=>r.json())
  },
  term(term){ return fetch('/api/terms/'+encodeURIComponent(term)).then(r=>r.json()) }
}
export default api
