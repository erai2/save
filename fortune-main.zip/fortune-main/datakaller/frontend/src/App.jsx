import React, { useEffect, useState, useCallback } from 'react'
import api from './api'
import { BarChart } from './components/Charts'
import Jobs from './components/Jobs'

export default function App(){
  const [health, setHealth] = useState(null)
  const [stats, setStats] = useState({ counts:{} })
  const [chunks, setChunks] = useState([])
  const [term, setTerm] = useState('응기')
  const [termRows, setTermRows] = useState([])
  const [lastJob, setLastJob] = useState(null)
  const refresh = useCallback(async ()=>{
    const [h,s] = await Promise.all([api.health(), api.stats()])
    setHealth(h); setStats(s)
  }, [])
  useEffect(()=>{ refresh() }, [refresh])

  const fetchChunks = async () => {
    const r = await api.labelChunks({ name: '응기_출현', min_score: 0.0, limit: 50 })
    setChunks(r)
  }
  const fetchTerm = async () => {
    const r = await api.term(term)
    setTermRows(r)
  }
  const runJob = async (name, params) => {
    const r = await api.runJob(name, params)
    setLastJob(r)
    await refresh()
  }

  const barData = Object.entries(stats.counts||{}).map(([k,v])=>({ k, v }))

  return (
    <div className="container">
      <div className="header">
        <h1>Databox 대시보드</h1>
        <span className="badge">{health?.ok ? 'API OK' : 'API 연결 대기'}</span>
      </div>

      <div className="row">
        <div className="card">
          <strong>DB 요약</strong>
          <div className="btns">
            <button onClick={refresh}>새로고침</button>
            <button onClick={()=>api.init()}>INIT SQL 재적용</button>
            <button onClick={()=>api.exportPassages()}>Passages CSV Export</button>
          </div>
          <BarChart data={barData} title="테이블별 행 수" />
          <div style={{ marginTop:8, display:'flex', gap:8, flexWrap:'wrap' }}>
            {Object.entries(stats.counts||{}).map(([k,v])=>(
              <span className="badge" key={k}>{k}: {v}</span>
            ))}
          </div>
        </div>

        <div className="card">
          <strong>라벨 청크 조회</strong>
          <div className="btns">
            <button onClick={fetchChunks}>응기_출현 가져오기</button>
          </div>
          <div style={{ maxHeight:260, overflow:'auto', marginTop:8 }}>
            <table className="table">
              <thead><tr><th>chunk_id</th><th>title</th><th>seq</th><th>score</th></tr></thead>
              <tbody>
                {(chunks||[]).map((c,i)=>(
                  <tr key={i}><td>{c.chunk_id}</td><td>{c.title}</td><td>{c.seq}</td><td>{c.score}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="card">
          <strong>용어 사전</strong>
          <div className="btns">
            <input value={term} onChange={e=>setTerm(e.target.value)} placeholder="term ex) 응기" />
            <button onClick={fetchTerm}>검색</button>
          </div>
          <div style={{ maxHeight:260, overflow:'auto' }}>
            <table className="table">
              <thead><tr><th>term</th><th>definition</th><th>source</th><th>example</th></tr></thead>
              <tbody>
                {(termRows||[]).map((r,i)=>(
                  <tr key={i}><td>{r.term}</td><td>{r.definition}</td><td>{r.source}</td><td>{r.example}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <Jobs onRun={runJob} last={lastJob} />
      </div>
    </div>
  )
}
