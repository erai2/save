from fastapi import FastAPI, Query, HTTPException
from app.db import connection

app = FastAPI(title="Suri Aux API", version="1.0.0")

@app.get("/terms/{term}")
def get_term(term: str):
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT t.term, d.definition, d.source, d.example
                    FROM dict_terms t
                    LEFT JOIN dict_defs d ON d.term_id = t.term_id
                    WHERE t.term=%s
                    """,
                    (term,),
                )
                rows = cur.fetchall()
        return [
            {"term": r[0], "definition": r[1], "source": r[2], "example": r[3]}
            for r in rows
        ]
    except Exception:
        # 내부 에러는 숨기고, 서버 로그에만 남기세요.
        raise HTTPException(status_code=500, detail="용어 조회 실패")

@app.get("/label/chunks")
def get_label_chunks(name: str = Query(...), min_score: float = 0.5):
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT c.chunk_id, s.title, c.seq, c.text, cl.score
                    FROM labels l
                    JOIN chunk_labels cl ON cl.label_id = l.label_id
                    JOIN doc_chunks c ON c.chunk_id = cl.chunk_id
                    JOIN doc_sources s ON s.doc_id = c.doc_id
                    WHERE l.name = %s AND cl.score >= %s
                    ORDER BY cl.score DESC
                    LIMIT 200
                    """,
                    (name, min_score),
                )
                rows = cur.fetchall()
        return [
            {"chunk_id": r[0], "doc_title": r[1], "seq": r[2], "text": r[3], "score": float(r[4])}
            for r in rows
        ]
    except Exception:
        raise HTTPException(status_code=500, detail="라벨 청크 조회 실패")

@app.post("/rules/reload")
def reload_rules():
    # 실제로는 hot-reload 트리거 또는 별도 작업을 호출
    return {"ok": True}
