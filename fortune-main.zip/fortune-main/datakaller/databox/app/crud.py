import re
from typing import Dict, List, Optional, Tuple

from app.db import connection

# ----------------------------
# 스키마 보조
# ----------------------------
def ensure_aux_schema():
    """
    최소 테이블만 보장. 101_terms.sql과 동일 구조 유지.
    """
    with connection() as conn:
        cur = conn.cursor()
        # labels / chunk_labels (101_terms.sql 기준)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS labels (
          label_id     SERIAL PRIMARY KEY,
          name         TEXT UNIQUE NOT NULL,
          description  TEXT
        );
        """)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS chunk_labels (
          chunk_id     INT REFERENCES doc_chunks(chunk_id) ON DELETE CASCADE,
          label_id     INT REFERENCES labels(label_id) ON DELETE CASCADE,
          score        REAL NOT NULL,
          PRIMARY KEY (chunk_id, label_id)
        );
        """)
        conn.commit()

# ----------------------------
# 라벨 등록/조회
# ----------------------------
def upsert_label(name: str, description: str = "") -> int:
    """labels(name, description) upsert 후 label_id 반환"""
    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO labels(name, description)
                    VALUES (%s, %s)
                    ON CONFLICT (name) DO UPDATE
                    SET description = EXCLUDED.description
                    RETURNING label_id
                    """,
                    (name, description),
                )
                return cur.fetchone()[0]

def bulk_upsert_labels(defs: Dict[str, str]) -> int:
    """여러 라벨 upsert, 개수 반환"""
    if not defs:
        return 0
    count = 0
    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                for name, desc in defs.items():
                    cur.execute(
                        """
                        INSERT INTO labels(name, description)
                        VALUES (%s, %s)
                        ON CONFLICT (name) DO UPDATE
                        SET description = EXCLUDED.description
                        """,
                        (name, desc),
                    )
                    count += 1
    return count

def get_all_labels() -> List[Dict[str, str]]:
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT name, coalesce(description,'') FROM labels ORDER BY name;")
            rows = cur.fetchall()
    return [{"name": r[0], "description": r[1]} for r in rows]

# ----------------------------
# 하이라이트 조회
# ----------------------------
def get_highlights_by_label(doc_id: int, label: str, limit: int = 200) -> List[Dict[str, str]]:
    """
    doc_sources/doc_chunks/labels/chunk_labels (101_terms.sql) 기준
    """
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT c.chunk_id, c.seq, c.text
                FROM labels l
                JOIN chunk_labels cl ON cl.label_id = l.label_id
                JOIN doc_chunks c ON c.chunk_id = cl.chunk_id
                WHERE c.doc_id = %s
                  AND l.name = %s
                ORDER BY cl.score DESC, c.seq ASC
                LIMIT %s
                """,
                (doc_id, label, limit),
            )
            rows = cur.fetchall()
    return [{"chunk_id": r[0], "seq": r[1], "text": r[2]} for r in rows]

# ----------------------------
# 자동 라벨링을 위한 기본 라벨/패턴
# ----------------------------
DEFAULT_CORE_LABELS: Dict[str, str] = {
    "응기_출현": "원국/대운/세운에서 글자가 '출현/등장/동(動)'하여 응기되는 구절",
    "응기_합동": "세운의 천간·지지가 원국/대운과 '합'하여 글자가 움직이는(合動) 구절",
    "응기_합유": "세운에서 원국/대운과 합하여 응기(合有)되는 구절",
    "천간합": "천간합(五合), 합거/합상/합반 등",
    "지지합": "육합/삼합/암합/반합/방합/공합 등",
    "형충파묘": "형/충/파/묘(입묘) 관련",
    "상법_대상": "帶象(대상) 관련",
    "적포구조": "賊神/捕神 적포구조 관련",
}

DEFAULT_CORE_PATTERNS: Dict[str, List[re.Pattern]] = {
    "응기_출현": [
        re.compile(r"응기"), re.compile(r"출현"), re.compile(r"등장"),
        re.compile(r"合?動|합동|동\(?\s*동?\)?"),
    ],
    "응기_합동": [re.compile(r"합동|合動")],
    "응기_합유": [re.compile(r"합유|合有")],
    "천간합": [
        re.compile(r"천간합|五合"),
        re.compile(r"합거|合去|합상|合傷|합반|合絆"),
    ],
    "지지합": [
        re.compile(r"육합|六合"), re.compile(r"삼합|三合"),
        re.compile(r"암합|暗合"), re.compile(r"반합|半合|二合"),
        re.compile(r"방합|方合"), re.compile(r"공합|拱合"),
    ],
    "형충파묘": [
        re.compile(r"형|刑"), re.compile(r"충|沖"),
        re.compile(r"파|破"), re.compile(r"묘|墓|입묘|入墓"),
    ],
    "상법_대상": [re.compile(r"대상|帶象")],
    "적포구조": [re.compile(r"적포구조|賊捕構造|賊捕"), re.compile(r"포신|捕神|적신|賊神")],
}

# ----------------------------
# 유틸: 청크 로드 & 패턴 매칭
# ----------------------------
def _fetch_chunks(doc_id: Optional[int] = None, limit: Optional[int] = None) -> List[Tuple[int, int, str]]:
    """
    doc_chunks에서 (chunk_id, seq, text) 반환
    """
    sql = """
        SELECT c.chunk_id, c.seq, c.text
        FROM doc_chunks c
        {where}
        ORDER BY c.doc_id, c.seq, c.chunk_id
        {limit}
    """
    where = "WHERE c.doc_id = %s" if doc_id is not None else ""
    limit_sql = "LIMIT %s" if limit is not None else ""

    with connection() as conn:
        with conn.cursor() as cur:
            if doc_id is not None and limit is not None:
                cur.execute(sql.format(where=where, limit=limit_sql), (doc_id, limit))
            elif doc_id is not None:
                cur.execute(sql.format(where=where, limit=limit_sql), (doc_id,))
            elif limit is not None:
                cur.execute(sql.format(where=where, limit=limit_sql), (limit,))
            else:
                cur.execute(sql.format(where=where, limit=limit_sql))
            rows = cur.fetchall()
    return [(r[0], r[1], r[2]) for r in rows]  # (chunk_id, seq, text)

def _match_labels(text: str, patterns: Dict[str, List[re.Pattern]]) -> List[str]:
    hits: List[str] = []
    for label, plist in patterns.items():
        for p in plist:
            if p.search(text or ""):
                hits.append(label)
                break
    return hits

# ----------------------------
# 자동 라벨링
# ----------------------------
def _ensure_label_ids(names: List[str]) -> Dict[str, int]:
    """라벨 이름 리스트를 label_id 매핑으로 보장/반환"""
    mapping: Dict[str, int] = {}
    if not names:
        return mapping
    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                for name in names:
                    cur.execute(
                        """
                        INSERT INTO labels(name) VALUES (%s)
                        ON CONFLICT (name) DO NOTHING
                        RETURNING label_id
                        """,
                        (name,),
                    )
                    row = cur.fetchone()
                    if row:
                        mapping[name] = row[0]
                # 누락된 것들은 SELECT로 회수
                missing = [n for n in names if n not in mapping]
                if missing:
                    cur.execute(
                        "SELECT name, label_id FROM labels WHERE name = ANY(%s)",
                        (missing,),
                    )
                    for nm, lid in cur.fetchall():
                        mapping[nm] = lid
    return mapping

def register_core_terms_and_autolabel(
    label_defs: Optional[Dict[str, str]] = None,
    patterns: Optional[Dict[str, List[re.Pattern]]] = None,
    doc_id: Optional[int] = None,
    sample_limit: Optional[int] = None
) -> Dict[str, int]:
    """
    1) 핵심 라벨 사전 등록 (labels)
    2) doc_chunks 스캔 → chunk_labels(label_id, score) upsert
    """
    ensure_aux_schema()

    label_defs = label_defs or DEFAULT_CORE_LABELS
    patterns = patterns or DEFAULT_CORE_PATTERNS

    # 1) 라벨 사전 등록
    bulk_upsert_labels(label_defs)
    label_count = len(label_defs)

    # 2) 청크 스캔
    chunks = _fetch_chunks(doc_id=doc_id, limit=sample_limit)
    labeled_chunks = 0
    inserted_pairs = 0

    # 필요한 label_id 확보
    label_ids = _ensure_label_ids(list(patterns.keys()))

    