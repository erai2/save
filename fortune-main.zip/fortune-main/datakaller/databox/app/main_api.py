from fastapi import FastAPI, Query, HTTPException, UploadFile, File, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import subprocess, os, io, csv
from datetime import datetime, date
from typing import Literal
from .db import connection

app = FastAPI(title="Databox API", version="1.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"], allow_credentials=True
)

# ---- Health ----
@app.get("/health")
def health():
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1;")
                cur.fetchone()
        return {"ok": True, "time": datetime.utcnow().isoformat() + "Z"}
    except Exception as e:
        raise HTTPException(500, f"DB 연결 실패: {e}")

# ---- Stats ----
@app.get("/stats")
def stats():
    counts = {}
    q = "SELECT table_name FROM information_schema.tables WHERE table_schema='public';"
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute(q)
                tables = [r[0] for r in cur.fetchall()]
                for name in ["suri_cases", "passages", "dict_terms", "dict_defs", "label_vocab", "label_rules", "suam_case_labels"]:
                    if name in tables:
                        cur.execute(f"SELECT COUNT(*) FROM {name};")
                        counts[name] = cur.fetchone()[0]
    except Exception as e:
        raise HTTPException(500, f"통계 조회 실패: {e}")
    return {"ok": True, "counts": counts}

# ---- INIT SQL 재적용 ----
@app.post("/init")
def init_sql():
    init_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "init"))
    ok = []
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                if not os.path.isdir(init_dir):
                    return {"ok": True, "applied": ok, "note": "init 디렉토리 없음"}
                for fname in sorted(os.listdir(init_dir)):
                    if not fname.endswith(".sql"): 
                        continue
                    path = os.path.join(init_dir, fname)
                    sql = open(path, "r", encoding="utf-8").read()
                    if not sql.strip():
                        continue
                    cur.execute(sql)
                    ok.append(fname)
            conn.commit()
        return {"ok": True, "applied": ok}
    except Exception as e:
        raise HTTPException(500, f"init 실행 실패: {e}")

# ---- CSV Export (passages) ----
@app.get("/export/passages.csv")
def export_passages():
    try:
        with connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT pid, doc_id, loc, kind, text FROM passages ORDER BY pid ASC LIMIT 5000;")
                rows = cur.fetchall()
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["pid","doc_id","loc","kind","text"])
        for r in rows:
            w.writerow(r)
        buf.seek(0)
        headers = {"Content-Disposition": 'attachment; filename="passages.csv"'}
        return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers=headers)
    except Exception as e:
        raise HTTPException(500, f"export 실패: {e}")

# ---- 스크립트 실행 ----
JobName = Literal[
    "ingest_chunks", "extract_terms", "semantic_labeler",
    "apply_rules", "embed_update", "load_and_classify"
]

SCRIPT_MAP = {
    "ingest_chunks": "scripts/ingest_chunks.py",
    "extract_terms": "scripts/extract_terms.py",
    "semantic_labeler": "scripts/semantic_labeler.py",
    "apply_rules": "scripts/apply_rules.py",
    "embed_update": "scripts/embed_update.py",
    "load_and_classify": "scripts/load_and_classify.py",
}

def run_job_cmd(job: str, params: dict[str, str]) -> tuple[int, str, str]:
    py = os.environ.get("PYTHON_BIN", "python")
    script = SCRIPT_MAP[job]
    cmd = [py, script]
    for k, v in (params or {}).items():
        if v is None or v == "":
            continue
        flag = f"--{k.replace('_','-')}"
        cmd += [flag, str(v)]
    proc = subprocess.Popen(cmd, cwd=os.path.abspath(os.path.join(os.path.dirname(__file__), "..")),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out, err = proc.communicate()
    return proc.returncode, out, err

from fastapi import Body
@app.post("/jobs/run")
def run_job(name: JobName = Body(..., embed=True), params: dict = Body(default={}, embed=True)):
    if name not in SCRIPT_MAP:
        raise HTTPException(400, f"지원하지 않는 작업: {name}")
    rc, out, err = run_job_cmd(name, params or {})
    return {"ok": rc == 0, "rc": rc, "stdout": out[-20000:], "stderr": err[-20000:], "cmd": {"name": name, "params": params}}

# ---- 기존 프로젝트의 엔드포인트가 있다면 별도 파일에서 import 해서 mount 가능 ----
try:
    from .extra_routes import mount_routes  # 선택적
    mount_routes(app)
except Exception:
    pass
