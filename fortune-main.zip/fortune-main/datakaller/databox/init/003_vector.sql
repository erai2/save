CREATE EXTENSION IF NOT EXISTS vector;

ALTER TABLE suri_cases
ADD COLUMN IF NOT EXISTS embedding vector(384);  -- MiniLM-L6-v2 기준 384차원

CREATE INDEX IF NOT EXISTS ix_suri_embedding
ON suri_cases USING ivfflat (embedding vector_l2_ops)
WITH (lists = 100);
