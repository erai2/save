-- 004_terms.sql
CREATE TABLE IF NOT EXISTS terms (
  term_id SERIAL PRIMARY KEY,
  term TEXT UNIQUE NOT NULL,               -- ex) '응기'
  defn TEXT,                                -- 정의/개념 요약
  notes TEXT,                               -- 상세 설명/주석
  rule_json JSONB DEFAULT '{}'::jsonb,      -- 해석 로직(트리거, 조건, 예외)
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 본문을 작은 단위로 쪼개 저장(추출과 분류의 최소단위)
CREATE TABLE IF NOT EXISTS passages (
  pid BIGSERIAL PRIMARY KEY,
  doc_id TEXT,                 -- 원문 파일/출처 식별자
  loc TEXT,                    -- 페이지/절/행 등 위치 정보
  text TEXT NOT NULL,
  kind TEXT,                   -- '정의'|'개념'|'사례'|'규칙'|'일반'
  embedding vector(384)
);

-- 용어와 본문 연결 (한 용어에 여러 발췌 연결)
CREATE TABLE IF NOT EXISTS term_passages (
  term_id INT REFERENCES terms(term_id) ON DELETE CASCADE,
  pid BIGINT REFERENCES passages(pid) ON DELETE CASCADE,
  rel TEXT,                    -- '정의근거'|'사례근거'|'규칙근거'
  PRIMARY KEY (term_id, pid)
);

-- 주제 라벨(기존 labels 와 호환) 부착
CREATE TABLE IF NOT EXISTS passage_labels (
  pid BIGINT REFERENCES passages(pid) ON DELETE CASCADE,
  label TEXT,
  PRIMARY KEY (pid, label)
);
