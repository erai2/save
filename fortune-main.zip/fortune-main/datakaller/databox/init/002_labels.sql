CREATE TABLE IF NOT EXISTS label_vocab (
  label_code  TEXT PRIMARY KEY,
  label_type  TEXT NOT NULL,   -- '격' | '직종' | '결과'
  name_ko     TEXT NOT NULL,
  active      BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS label_rules (
  rule_id     BIGSERIAL PRIMARY KEY,
  label_code  TEXT NOT NULL REFERENCES label_vocab(label_code) ON DELETE CASCADE,
  pattern     TEXT NOT NULL,    -- PostgreSQL regex
  priority    INT  DEFAULT 100, -- 낮을수록 우선
  note        TEXT
);

CREATE TABLE IF NOT EXISTS suam_case_labels (
  case_id     BIGINT NOT NULL REFERENCES suam_cases(case_id) ON DELETE CASCADE,
  label_code  TEXT   NOT NULL REFERENCES label_vocab(label_code) ON DELETE CASCADE,
  rule_id     BIGINT NOT NULL REFERENCES label_rules(rule_id) ON DELETE CASCADE,
  matched_at  TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (case_id, label_code, rule_id)
);

CREATE OR REPLACE VIEW suam_case_labels_expanded AS
SELECT l.case_id, v.label_type, v.label_code, v.name_ko, l.rule_id, l.matched_at
FROM suam_case_labels l
JOIN label_vocab v ON v.label_code = l.label_code;

-- 임시 어휘 시드
INSERT INTO label_vocab(label_code, label_type, name_ko) VALUES
('G_TMP_01','격','재통관(財統官)'),
('G_TMP_02','격','관통재(官統財)'),
('G_TMP_03','격','금수상관'),
('G_TMP_04','격','수목상관'),
('G_TMP_05','격','토금상관'),
('G_TMP_06','격','비겁왕+인(귀격)'),
('J_TMP_01','직종','부동산'),
('J_TMP_02','직종','운수업/차량'),
('J_TMP_03','직종','은행관리/금융'),
('J_TMP_04','직종','판매업/소매'),
('J_TMP_05','직종','무역/해외'),
('J_TMP_06','직종','장식/채색'),
('J_TMP_07','직종','의사/의료'),
('J_TMP_08','직종','약국/의약'),
('J_TMP_09','직종','술집/요식'),
('R_TMP_01','결과','발재(재물획득)'),
('R_TMP_02','결과','파재(손실)'),
('R_TMP_03','결과','관재/구설/감옥'),
('R_TMP_04','결과','결혼/이혼/독신'),
('R_TMP_05','결과','병/수술'),
('R_TMP_06','결과','사망/상')
ON CONFLICT (label_code) DO NOTHING;

-- 규칙 시드(정규식)
INSERT INTO label_rules(label_code, pattern, priority, note) VALUES
('G_TMP_01','(財統官格|재통\\s*관格|재통관)',50,'재통관격'),
('G_TMP_02','(官統財格|관통\\s*재格|관통재)',50,'관통재격'),
('G_TMP_03','(金水傷官格|⾦⽔傷官格|금수상관格|금수상관)',80,'금·수 상관'),
('G_TMP_04','(水木傷官格|⽔⽊傷官格|수목상관格|수목상관)',80,'수·목 상관'),
('G_TMP_05','(土金傷官格|⼟⾦傷官格|토금상관格|토금상관)',80,'토·금 상관'),
('G_TMP_06','(比劫.*印.*(貴|귀格)|비겁.*인.*귀格|比劫王.*印)',120,'비겁왕+인'),
('J_TMP_01','(부동산|房세|방세|빌딩|부동산업)',60,'부동산'),
('J_TMP_02','(운수업|차량\\s*의\\s*象|차량사고|차\\(⾞\\))',90,'운수/차량'),
('J_TMP_03','(은행\\s*관리|은행\\s*을\\s*관리|은행\\s*관리직|금융)',70,'은행/금융'),
('J_TMP_04','(판매업|가게\\s*운영|소매|슈퍼마켓)',80,'판매/소매'),
('J_TMP_05','(무역|해외무역|海外\\s*貿易|驛馬\\+財)',70,'무역/해외'),
('J_TMP_06','(장식업|실내\\s*장식|채색업|그림|글씨\\s*써주는)',70,'장식/채색'),
('J_TMP_07','(의사|내과의사|병원에서\\s*의사)',70,'의사/의료'),
('J_TMP_08','(약국|의약|藥|약재)',100,'약국/의약'),
('J_TMP_09','(술집|요식|아이들이\\s*몰려와\\s*財.*술집)',110,'술집/요식'),
('R_TMP_01','(발재|大財|거부|巨富|재벌|재물\\s*취|財運\\s*좋|재를\\s*취)',60,'재물 획득'),
('R_TMP_02','(파재|손실|잃어|도둑|보상금\\s*지급)',70,'재물 손실'),
('R_TMP_03','(관재\\s*구설|관재구설|감옥|관재\\)|감옥에\\s*간다)',50,'법적 문제'),
('R_TMP_04','(결혼|혼인|이혼|독신|무자식|애인이다)',120,'혼인/자녀'),
('R_TMP_05','(병원\\s*개설|수술하였|병을\\s*얻|당뇨병|병원운영\\s*곤난)',100,'질병/수술'),
('R_TMP_06','(사망|수명성|사망할\\s*것|부인이\\s*사망)',80,'사망/상');

-- 분류 함수/트리거
CREATE OR REPLACE FUNCTION classify_case(p_case_id BIGINT)
RETURNS VOID
LANGUAGE plpgsql AS $$
DECLARE txt TEXT;
BEGIN
  SELECT combined_text INTO txt FROM suri_cases WHERE case_id = p_case_id;
  IF txt IS NULL THEN RETURN; END IF;

  DELETE FROM suri_case_labels WHERE case_id = p_case_id;

  INSERT INTO suri_case_labels(case_id, label_code, rule_id)
  SELECT p_case_id, r.label_code, r.rule_id
  FROM label_rules r
  JOIN label_vocab v ON v.label_code = r.label_code AND v.active
  WHERE txt ~* r.pattern
  ORDER BY r.priority ASC;
END$$;

CREATE OR REPLACE FUNCTION classify_all(p_limit INT DEFAULT NULL)
RETURNS VOID
LANGUAGE plpgsql AS $$
DECLARE rec RECORD; sql TEXT;
BEGIN
  sql := 'SELECT case_id FROM suri_cases ORDER BY case_id';
  IF p_limit IS NOT NULL THEN sql := sql || ' LIMIT '||p_limit::TEXT; END IF;
  FOR rec IN EXECUTE sql LOOP
    PERFORM classify_case(rec.case_id);
  END LOOP;
END$$;

DROP TRIGGER IF EXISTS trg_classify_case_ins ON suri_cases;
CREATE TRIGGER trg_classify_case_ins
AFTER INSERT ON suri_cases
FOR EACH ROW EXECUTE FUNCTION classify_case(NEW.case_id);
