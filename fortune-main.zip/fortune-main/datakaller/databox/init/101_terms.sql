-- 101_terms.sql
CREATE TABLE IF NOT EXISTS dict_terms (
  term_id      SERIAL PRIMARY KEY,
  term         TEXT UNIQUE NOT NULL,      -- 예: '응기'
  pos          TEXT,                      -- 품사/분류(선택)
  created_at   TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dict_defs (
  def_id       SERIAL PRIMARY KEY,
  term_id      INT NOT NULL REFERENCES dict_terms(term_id) ON DELETE CASCADE,
  definition   TEXT NOT NULL,             -- 정의 원문
  source       TEXT,                      -- 출처 파일/책
  example      TEXT,                      -- 예시
  created_at   TIMESTAMP DEFAULT now()
);

-- 문서/청크 저장 및 임베딩
CREATE TABLE IF NOT EXISTS doc_sources (
  doc_id       SERIAL PRIMARY KEY,
  title        TEXT,
  path         TEXT,
  meta         JSONB,
  created_at   TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS doc_chunks (
  chunk_id     SERIAL PRIMARY KEY,
  doc_id       INT REFERENCES doc_sources(doc_id) ON DELETE CASCADE,
  seq          INT NOT NULL,
  text         TEXT NOT NULL,
  embedding    vector(384)                -- pgvector
);

CREATE INDEX IF NOT EXISTS ix_chunks_vec
  ON doc_chunks USING ivfflat (embedding vector_l2_ops) WITH (lists = 100);

-- 용어가 어디서 발견됐는지(거명/공기) 역추적
CREATE TABLE IF NOT EXISTS term_hits (
  hit_id       SERIAL PRIMARY KEY,
  term_id      INT NOT NULL REFERENCES dict_terms(term_id) ON DELETE CASCADE,
  chunk_id     INT NOT NULL REFERENCES doc_chunks(chunk_id) ON DELETE CASCADE,
  span         int4range,                 -- 텍스트 내 위치(선택)
  confidence   REAL,                      -- 간단 신뢰도
  created_at   TIMESTAMP DEFAULT now()
);

-- 분류(라벨)
CREATE TABLE IF NOT EXISTS labels (
  label_id     SERIAL PRIMARY KEY,
  name         TEXT UNIQUE NOT NULL,      -- 예: '응기_출현', '응기_합동'
  description  TEXT
);

CREATE TABLE IF NOT EXISTS chunk_labels (
  chunk_id     INT REFERENCES doc_chunks(chunk_id) ON DELETE CASCADE,
  label_id     INT REFERENCES labels(label_id) ON DELETE CASCADE,
  score        REAL NOT NULL,             -- 0~1
  PRIMARY KEY (chunk_id, label_id)
);

-- 해석 로직(룰)
CREATE TABLE IF NOT EXISTS rules (
  rule_id      SERIAL PRIMARY KEY,
  name         TEXT UNIQUE NOT NULL,      -- 예: '응기_출현'
  kind         TEXT NOT NULL,             -- 'pattern' | 'semantic' | 'hybrid'
  config       JSONB NOT NULL,            -- 매칭용 설정(정규식/키워드/threshold 등)
  target_label INT REFERENCES labels(label_id),
  enabled      BOOLEAN DEFAULT TRUE
);
