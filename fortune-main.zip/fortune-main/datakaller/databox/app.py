# app.py
import os
import json
import time
import subprocess
from datetime import datetime

import pandas as pd
import requests
import streamlit as st

st.set_page_config(page_title="AI 문서 대시보드", layout="wide")

# ----------------------------
# 설정(필요시 환경변수로 덮어쓰기)
# ----------------------------
BACKEND_MAIN = os.getenv("BACKEND_MAIN", "http://localhost:8000")   # main.py
BACKEND_AUX  = os.getenv("BACKEND_AUX",  "http://localhost:8001")   # main_api.py
PYTHON_BIN   = os.getenv("PYTHON_BIN", "python")

# ----------------------------
# 유틸
# ----------------------------
def ping(url: str) -> tuple[bool, dict | list | None]:
    try:
        r = requests.get(url, timeout=5)
        if r.ok:
            return True, r.json()
        return False, None
    except Exception:
        return False, None

def run_cmd(cmd: list[str]) -> tuple[int, str, str]:
    """
    로컬 스크립트 실행. stdout/stderr 텍스트 반환.
    """
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    out, err = proc.communicate()
    return proc.returncode, out, err

def pretty_json(obj) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2)
    except Exception:
        return str(obj)

# ----------------------------
# 헤더
# ----------------------------
st.title("📚 AI 문서 관리 대시보드")
st.caption(f"접속 시각: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

colA, colB = st.columns(2)
with colA:
    ok_main, data_main = ping(f"{BACKEND_MAIN}/health")
    st.subheader("Main API (main.py)")
    if ok_main:
        st.success("✅ 연결됨")
        st.code(pretty_json(data_main), language="json")
    else:
        st.error(f"❌ 연결 실패: {BACKEND_MAIN}/health")

with colB:
    st.subheader("Aux API (main_api.py)")
    # aux에는 health가 없으니 라벨 청크 엔드포인트로 간단 체크
    ok_aux, _ = ping(f"{BACKEND_AUX}/label/chunks?name=응기_출현&min_score=0.0&limit=1")
    if ok_aux:
        st.success("✅ 연결됨")
    else:
        st.warning(f"연결을 확인하세요: {BACKEND_AUX}")

st.divider()

# ----------------------------
# 사이드 메뉴
# ----------------------------
st.sidebar.title("📊 메뉴")
menu = st.sidebar.radio("이동", (
    "⚙️ 빠른 실행",
    "📈 라벨 분포/랭킹",
    "🔍 라벨별 하이라이트",
    "📜 로그 / 출력"
))

# 공용 상태 저장소
if "last_stdout" not in st.session_state:
    st.session_state.last_stdout = ""
if "last_stderr" not in st.session_state:
    st.session_state.last_stderr = ""
if "last_cmd" not in st.session_state:
    st.session_state.last_cmd = ""

# ----------------------------
# ⚙️ 빠른 실행 (스크립트 버튼)
# ----------------------------
if menu == "⚙️ 빠른 실행":
    st.subheader("원클릭 파이프라인 실행")

    with st.expander("📥 문서 적재 / 임베딩 생성 (ingest_chunks.py)"):
        path = st.text_input("문서 폴더 경로", "./corpus")
        batch_size = st.number_input("배치 크기", min_value=10, max_value=2000, value=200, step=10)
        max_len = st.number_input("청크 최대 길이", min_value=100, max_value=4000, value=600, step=50)
        if st.button("실행: ingest_chunks"):
            cmd = [PYTHON_BIN, "ingest_chunks.py", "--path", path, "--batch-size", str(batch_size), "--max-len", str(max_len)]
            with st.spinner("실행 중..."):
                rc, out, err = run_cmd(cmd)
            st.session_state.last_cmd = " ".join(cmd)
            st.session_state.last_stdout = out
            st.session_state.last_stderr = err
            (st.success if rc == 0 else st.error)(f"종료 코드: {rc}")

    with st.expander("🧩 규칙 라벨링 (apply_rules.py)"):
        min_score = st.number_input("최소 스코어", min_value=0.0, max_value=1.0, value=0.6, step=0.05)
        limit = st.number_input("처리 제한(선택)", min_value=0, max_value=1_000_000, value=0, step=1000)
        dry = st.checkbox("드라이런", value=False)
        if st.button("실행: apply_rules"):
            cmd = [PYTHON_BIN, "apply_rules.py", "--min-score", str(min_score)]
            if limit > 0: cmd += ["--limit", str(limit)]
            if dry: cmd += ["--dry-run"]
            with st.spinner("실행 중..."):
                rc, out, err = run_cmd(cmd)
            st.session_state.last_cmd = " ".join(cmd)
            st.session_state.last_stdout = out
            st.session_state.last_stderr = err
            (st.success if rc == 0 else st.error)(f"종료 코드: {rc}")

    with st.expander("🧠 의미 라벨링 (semantic_labeler.py)"):
        th = st.number_input("임계값", min_value=0.0, max_value=1.0, value=0.55, step=0.01)
        limit_chunks = st.number_input("chunk 제한(선택)", min_value=0, max_value=5_000_000, value=0, step=5000)
        dry2 = st.checkbox("드라이런(semantic)", value=False)
        if st.button("실행: semantic_labeler"):
            cmd = [PYTHON_BIN, "semantic_labeler.py", "--threshold", str(th)]
            if limit_chunks > 0: cmd += ["--limit-chunks", str(limit_chunks)]
            if dry2: cmd += ["--dry-run"]
            with st.spinner("실행 중..."):
                rc, out, err = run_cmd(cmd)
            st.session_state.last_cmd = " ".join(cmd)
            st.session_state.last_stdout = out
            st.session_state.last_stderr = err
            (st.success if rc == 0 else st.error)(f"종료 코드: {rc}")

    with st.expander("🔎 용어 히트 추출 (extract_terms.py)"):
        limit_chunks2 = st.number_input("chunk 제한(선택)", min_value=0, max_value=5_000_000, value=0, step=5000, key="limit_chunks2")
        dry3 = st.checkbox("드라이런(terms)", value=True, key="dry3")
        if st.button("실행: extract_terms"):
            cmd = [PYTHON_BIN, "extract_terms.py"]
            if limit_chunks2 > 0: cmd += ["--limit-chunks", str(limit_chunks2)]
            if dry3: cmd += ["--dry-run"]
            with st.spinner("실행 중..."):
                rc, out, err = run_cmd(cmd)
            st.session_state.last_cmd = " ".join(cmd)
            st.session_state.last_stdout = out
            st.session_state.last_stderr = err
            (st.success if rc == 0 else st.error)(f"종료 코드: {rc}")

    with st.expander("🧬 케이스 임베딩 업데이트 (embed_update.py)"):
        limit_cases = st.number_input("업데이트 제한(선택)", min_value=0, max_value=5_000_000, value=0, step=1000)
        emb_bs = st.number_input("배치 크기", min_value=8, max_value=1024, value=128, step=8)
        norm_off = st.checkbox("정규화 끄기", value=False)
        if st.button("실행: embed_update"):
            cmd = [PYTHON_BIN, "embed_update.py", "--batch-size", str(emb_bs)]
            if limit_cases > 0: cmd += ["--limit", str(limit_cases)]
            if norm_off: cmd += ["--no-normalize"]
            with st.spinner("실행 중..."):
                rc, out, err = run_cmd(cmd)
            st.session_state.last_cmd = " ".join(cmd)
            st.session_state.last_stdout = out
            st.session_state.last_stderr = err
            (st.success if rc == 0 else st.error)(f"종료 코드: {rc}")

# ----------------------------
# 📈 라벨 분포/랭킹
# ----------------------------
elif menu == "📈 라벨 분포/랭킹":
    st.subheader("라벨 분포")
    # 라벨 목록
    try:
        res = requests.get(f"{BACKEND_MAIN}/labels", timeout=5)
        labels = [x["name"] for x in res.json().get("labels", [])] if res.ok else []
    except Exception:
        labels = []

    selected = st.multiselect("라벨 선택", options=labels, default=labels[:5])
    min_score = st.slider("최소 스코어", 0.0, 1.0, 0.5, 0.01)
    limit = st.number_input("각 라벨별 상위 N", min_value=1, max_value=2000, value=200)

    rows_all = []
    for lb in selected:
        try:
            r = requests.get(
                f"{BACKEND_AUX}/label/chunks",
                params={"name": lb, "min_score": min_score, "limit": limit},
                timeout=20,
            )
            if r.ok:
                items = r.json()
                for it in items:
                    rows_all.append({"label": lb, **it})
        except Exception:
            pass

    if not rows_all:
        st.info("데이터가 없습니다. 상단의 빠른 실행으로 라벨링을 먼저 수행해보세요.")
    else:
        df = pd.DataFrame(rows_all)
        st.write("상위 결과 미리보기")
        st.dataframe(df.head(200), use_container_width=True)

        st.write("라벨별 개수")
        st.bar_chart(df.groupby("label")["chunk_id"].count())

        st.write("문서 제목별 상위 빈도")
        st.bar_chart(df.groupby("doc_title")["chunk_id"].count().sort_values(ascending=False).head(20))

        st.write("스코어 분포 (히스토그램 대체)")
        st.bar_chart(df["score"].round(2).value_counts().sort_index())

# ----------------------------
# 🔍 라벨별 하이라이트
# ----------------------------
elif menu == "🔍 라벨별 하이라이트":
    st.subheader("특정 문서 내 라벨 하이라이트")
    doc_id = st.number_input("doc_id (doc_sources.doc_id)", min_value=1, value=1, step=1)
    label = st.text_input("라벨명", "응기_출현")
    limit = st.number_input("최대 개수", min_value=1, max_value=2000, value=200)

    if st.button("조회"):
        try:
            r = requests.get(f"{BACKEND_MAIN}/docs/{doc_id}/highlights", params={"label": label, "limit": limit}, timeout=20)
            if r.ok:
                data = r.json()
                st.success("조회 완료")
                st.code(pretty_json(data), language="json")
                if isinstance(data, dict) and "highlights" in data:
                    dfx = pd.DataFrame(data["highlights"])
                    st.dataframe(dfx, use_container_width=True)
                    st.bar_chart(dfx["seq"].value_counts().sort_index())
            else:
                st.error(f"조회 실패: {r.status_code}")
        except Exception as e:
            st.error(f"오류: {e}")

# ----------------------------
# 📜 로그 / 출력
# ----------------------------
elif menu == "📜 로그 / 출력":
    st.subheader("최근 실행 로그")
    st.text_area("실행 커맨드", st.session_state.last_cmd, height=40)
    st.text_area("STDOUT", st.session_state.last_stdout, height=240)
    st.text_area("STDERR", st.session_state.last_stderr, height=200)
