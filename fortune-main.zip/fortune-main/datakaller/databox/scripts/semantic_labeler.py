# semantic_labeler.py
import argparse, time, logging
import numpy as np
from sentence_transformers import SentenceTransformer
from app.db import connection

MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

LABEL_SEEDS = {
  "응기_출현": [
    "운에서 원국의 간지가 출현하면 응기가 된다",
    "세운에 나타난 글자가 원국 글자를 움직이면 그 해가 응기다",
  ],
  "응기_합동": [
    "운의 천간이 원국과 합하면 합동으로 움직인다",
    "같은 오행이 합하여 동(動)한다",
  ],
  "응기_합유": [
    "세운이 원국과 합하면 혼인의 응기를 판단한다",
    "합하여 응기로 본다(혼인)",
  ],
}

def setup_logging(level: str):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def _cos_sim(a: np.ndarray, b: np.ndarray) -> float:
    na = np.linalg.norm(a); nb = np.linalg.norm(b)
    if na == 0.0 or nb == 0.0: return -1.0
    return float(np.dot(a, b) / (na * nb))

def run(threshold: float, limit_chunks: int | None, log_every: int, dry_run: bool):
    log = logging.getLogger("semantic_labeler")
    t0 = time.perf_counter()

    with connection() as conn:
        # label name -> id
        with conn.cursor() as cur:
            cur.execute("SELECT name, label_id FROM labels")
            name_to_id = dict(cur.fetchall())

        # seed centers (only labels that exist)
        seed_centers = {
            name: np.mean(MODEL.encode(texts, convert_to_numpy=True), axis=0)
            for name, texts in LABEL_SEEDS.items() if name in name_to_id
        }
        if not seed_centers:
            log.warning("No matching labels found for seeds. Abort.")
            return

        # chunks
        with conn.cursor() as cur:
            q = "SELECT chunk_id, embedding FROM doc_chunks WHERE embedding IS NOT NULL"
            if limit_chunks: q += " LIMIT %s"; cur.execute(q, (limit_chunks,))
            else: cur.execute(q)
            rows = cur.fetchall()
    log.info("Loaded %d chunks; seeds=%s", len(rows), ",".join(seed_centers.keys()))

    inserts, seen = [], 0
    for chunk_id, emb in rows:
        vec = np.asarray(emb, dtype=np.float32)
        best_name, best_sim = None, -1.0
        for name, center in seed_centers.items():
            sim = _cos_sim(vec, center)
            if sim > best_sim: best_name, best_sim = name, sim
        if best_name and best_sim >= threshold:
            inserts.append((chunk_id, name_to_id[best_name], float(best_sim)))
        seen += 1
        if seen % log_every == 0:
            log.info("Scored %d/%d (%.1f%%), matches=%d", seen, len(rows), 100*seen/max(1,len(rows)), len(inserts))

    if dry_run:
        log.info("[DRY-RUN] %d matches found. No DB writes.", len(inserts))
        return

    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                for chunk_id, label_id, score in inserts:
                    cur.execute("""
                        INSERT INTO chunk_labels(chunk_id,label_id,score)
                        VALUES (%s,%s,%s)
                        ON CONFLICT (chunk_id,label_id) DO UPDATE
                        SET score=GREATEST(chunk_labels.score, EXCLUDED.score)
                    """, (chunk_id, label_id, score))

    dt = time.perf_counter() - t0
    log.info("Applied %d semantic labels in %.2fs", len(inserts), dt)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=0.53)
    ap.add_argument("--limit-chunks", type=int)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    ap.add_argument("--log-every", type=int, default=2000)
    args = ap.parse_args()
    setup_logging(args.log_level)
    run(args.threshold, args.limit_chunks, args.log_every, args.dry_run)
