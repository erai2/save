# ingest_chunks.py
import pathlib, re, argparse, time, logging
from typing import List
import psycopg2.extras
from sentence_transformers import SentenceTransformer
from app.db import connection

MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

def setup_logging(level: str):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def split_to_chunks(text: str, max_len=600) -> List[str]:
    paras = re.split(r"\n{2,}", (text or "").strip())
    chunks, buf, size = [], [], 0
    for p in paras:
        if size + len(p) <= max_len:
            buf.append(p); size += len(p)
        else:
            if buf: chunks.append("\n".join(buf))
            buf, size = [p], len(p)
    if buf: chunks.append("\n".join(buf))
    return chunks

def upsert_doc(conn, title: str, path: str, meta=None) -> int:
    with conn.cursor() as cur:
        cur.execute("""
            INSERT INTO doc_sources(title, path, meta)
            VALUES (%s,%s,%s)
            ON CONFLICT DO NOTHING RETURNING doc_id
        """, (title, path, psycopg2.extras.Json(meta or {})))
        if cur.rowcount:
            return cur.fetchone()[0]
        cur.execute("SELECT doc_id FROM doc_sources WHERE path=%s", (path,))
        return cur.fetchone()[0]

def insert_chunks(conn, doc_id: int, chunks: List[str], batch_size: int):
    embs = MODEL.encode(chunks, convert_to_numpy=True)
    with conn:
        with conn.cursor() as cur:
            rows = [(doc_id, i, t, list(e)) for i, (t, e) in enumerate(zip(chunks, embs))]
            psycopg2.extras.execute_values(
                cur,
                "INSERT INTO doc_chunks(doc_id, seq, text, embedding) VALUES %s",
                rows, page_size=batch_size,
            )

def run(input_path: str, batch_size: int, max_len: int, log_every: int):
    log = logging.getLogger("ingest_chunks")
    t0 = time.perf_counter()

    p = pathlib.Path(input_path)
    files = list(p.rglob("*.txt"))
    log.info("Found %d .txt files under %s", len(files), input_path)

    done_docs, done_chunks = 0, 0
    with connection() as conn:
        for idx, file in enumerate(files, 1):
            text = file.read_text(encoding="utf-8", errors="ignore")
            chunks = split_to_chunks(text, max_len=max_len)
            if not chunks:
                continue
            doc_id = upsert_doc(conn, file.stem, str(file))
            insert_chunks(conn, doc_id, chunks, batch_size=batch_size)
            done_docs += 1; done_chunks += len(chunks)
            if idx % max(1, log_every) == 0:
                log.info("Ingested %d/%d files, total chunks=%d", idx, len(files), done_chunks)

    dt = time.perf_counter() - t0
    log.info("Done. docs=%d, chunks=%d in %.2fs", done_docs, done_chunks, dt)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", default="./corpus", help="folder containing .txt files")
    ap.add_argument("--batch-size", type=int, default=200)
    ap.add_argument("--max-len", type=int, default=600)
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    ap.add_argument("--log-every", type=int, default=10, help="log every N files")
    args = ap.parse_args()
    setup_logging(args.log_level)
    run(args.path, args.batch_size, args.max_len, args.log_every)
