# extract_terms.py
import re, argparse, time, logging
from app.db import connection

def setup_logging(level: str):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def fetch_terms(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT term_id, term FROM dict_terms")
        return dict(cur.fetchall())

def find_hits(text, term):
    pat = re.compile(rf"(?<![가-힣]){re.escape(term)}(?![가-힣])")
    return [m.span() for m in pat.finditer(text or "")]

def run(limit_chunks: int | None, log_every: int, dry_run: bool):
    log = logging.getLogger("extract_terms")
    t0 = time.perf_counter()

    with connection() as conn:
        terms = fetch_terms(conn)
        with conn.cursor() as cur:
            q = "SELECT chunk_id, text FROM doc_chunks"
            if limit_chunks: q += " LIMIT %s"; cur.execute(q, (limit_chunks,))
            else: cur.execute(q)
            rows = cur.fetchall()
    log.info("Loaded %d terms, %d chunks", len(terms), len(rows))

    inserts, seen = [], 0
    for chunk_id, text in rows:
        for term_id, term in terms.items():
            for s, e in find_hits(text, term):
                inserts.append((term_id, chunk_id, s, e, 0.9))
        seen += 1
        if seen % log_every == 0:
            log.info("Scanned %d/%d chunks (%.1f%%)", seen, len(rows), 100*seen/max(1,len(rows)))

    if dry_run:
        log.info("[DRY-RUN] %d hits found. No DB writes.", len(inserts))
        return

    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                for term_id, chunk_id, s, e, conf in inserts:
                    cur.execute("""
                        INSERT INTO term_hits(term_id, chunk_id, span, confidence)
                        VALUES (%s,%s,int4range(%s,%s),%s)
                        ON CONFLICT DO NOTHING
                    """, (term_id, chunk_id, s, e, conf))

    dt = time.perf_counter() - t0
    log.info("Inserted %d hits in %.2fs", len(inserts), dt)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit-chunks", type=int)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    ap.add_argument("--log-every", type=int, default=1000)
    args = ap.parse_args()
    setup_logging(args.log_level)
    run(args.limit_chunks, args.log_every, args.dry_run)
