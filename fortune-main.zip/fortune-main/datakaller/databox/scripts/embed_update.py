#!/usr/bin/env python3
import argparse, time, logging
from typing import List, Tuple
import numpy as np
from sentence_transformers import SentenceTransformer
from app.db import connection

MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

def setup_logging(level: str):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def _iter_batches(rows: List[Tuple[int, str | None]], batch_size: int):
    for i in range(0, len(rows), batch_size):
        yield rows[i:i + batch_size]

def update_embeddings(limit: int | None, batch_size: int, normalize: bool, log_every: int):
    log = logging.getLogger("embed_update")
    t0 = time.perf_counter()

    with connection() as conn:
        with conn.cursor() as cur:
            q = "SELECT case_id, combined_text FROM suri_cases WHERE embedding IS NULL"
            if limit: q += " LIMIT %s"; cur.execute(q, (limit,))
            else: cur.execute(q)
            rows = cur.fetchall()
    log.info("To update: %d rows", len(rows))

    updated = 0
    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                for batch in _iter_batches(rows, batch_size):
                    texts = [t or "" for _, t in batch]
                    vecs = MODEL.encode(texts, normalize_embeddings=normalize)
                    for (case_id, _), vec in zip(batch, vecs):
                        cur.execute("UPDATE suri_cases SET embedding = %s WHERE case_id = %s",
                                    (list(vec), case_id))
                        updated += 1
                        if updated % log_every == 0:
                            log.info("Updated %d / %d", updated, len(rows))

    dt = time.perf_counter() - t0
    rps = updated/dt if dt else 0.0
    log.info("Updated %d embeddings in %.2fs (%.1f rows/s)", updated, dt, rps)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--no-normalize", action="store_true", help="disable embedding normalization")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    ap.add_argument("--log-every", type=int, default=500)
    args = ap.parse_args()
    setup_logging(args.log_level)
    update_embeddings(args.limit, args.batch_size, not args.no_normalize, args.log_every)
