# scripts/apply_rules.py
import json, re, time, argparse, logging
from typing import List, Tuple
from psycopg2.extras import execute_values
from app.db import connection

def setup_logging(level: str):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

def hit_pattern(text: str | None, cfg: dict) -> float:
    text = text or ""
    any_terms = cfg.get("any", [])
    near = cfg.get("near", [])   # [["운","응기"], ...]
    window = int(cfg.get("window", 80))

    if any_terms and not any(re.search(t, text) for t in any_terms):
        return 0.0

    for a, b in near:
        for ma in re.finditer(a, text):
            s = max(0, ma.start() - window)
            e = min(len(text), ma.end() + window)
            if re.search(b, text[s:e]):
                return 0.9
    return 0.6 if any_terms else 0.0

def run(min_score: float, limit: int | None, dry_run: bool, log_every: int, page_size: int):
    log = logging.getLogger("apply_rules")
    t0 = time.perf_counter()

    # 규칙, 청크 로드
    with connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT rule_id, name, kind, config, target_label FROM rules WHERE enabled")
            rules = cur.fetchall()
            q = "SELECT chunk_id, text FROM doc_chunks"
            if limit:
                q += " LIMIT %s"; cur.execute(q, (limit,))
            else:
                cur.execute(q)
            chunks: List[Tuple[int, str]] = cur.fetchall()

    log.info("Loaded %d rules, %d chunks", len(rules), len(chunks))

    # 매칭
    inserts, seen = [], 0
    for chunk_id, text in chunks:
        for rule_id, name, kind, cfg_json, label_id in rules:
            if kind != "pattern":
                continue
            score = hit_pattern(text, json.loads(cfg_json))
            if score >= min_score:
                inserts.append((chunk_id, label_id, score))
        seen += 1
        if seen % log_every == 0:
            log.info("Scanned %d/%d chunks (%.1f%%)", seen, len(chunks), 100*seen/max(1,len(chunks)))

    if dry_run:
        log.info("[DRY-RUN] %d matches found. No DB writes.", len(inserts))
        return

    if not inserts:
        log.info("No matches to apply.")
        return

    # 일괄 upsert
    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                execute_values(
                    cur,
                    """
                    INSERT INTO chunk_labels (chunk_id, label_id, score)
                    VALUES %s
                    ON CONFLICT (chunk_id, label_id)
                    DO UPDATE SET score = GREATEST(chunk_labels.score, EXCLUDED.score)
                    """,
                    inserts,
                    page_size=page_size,
                )

    dt = time.perf_counter() - t0
    rps = len(chunks)/dt if dt else 0.0
    log.info("Applied %d labels in %.2fs (%.1f chunks/s)", len(inserts), dt, rps)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-score", type=float, default=0.6)
    ap.add_argument("--limit", type=int)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--page-size", type=int, default=1000, help="execute_values page size")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    ap.add_argument("--log-every", type=int, default=1000)
    args = ap.parse_args()
    setup_logging(args.log_level)
    run(args.min_score, args.limit, args.dry_run, args.log_every, args.page_size)
