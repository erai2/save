#!/usr/bin/env python3
import argparse, json, hashlib, time, logging
import psycopg2.extras
from app.db import connection

def setup_logging(level: str):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def sha256(b: bytes) -> str:
    h = hashlib.sha256(); h.update(b); return h.hexdigest()

def run(file_path: str, limit: int | None, load_all: bool, log_every: int):
    log = logging.getLogger("load_and_classify")
    t0 = time.perf_counter()

    raw = open(file_path, "rb").read()
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, list):
        raise SystemExit("Input JSON must be an array")
    items = data if load_all else data[: (limit or 10)]
    file_hash = sha256(raw)

    rows_raw, rows_norm = [], []
    for i, obj in enumerate(items, 1):
        jtxt = json.dumps(obj, ensure_ascii=False, sort_keys=True)
        row_hash = sha256(jtxt.encode("utf-8"))
        rows_raw.append((jtxt, file_hash, row_hash))
        rows_norm.append((
            obj.get("title"), obj.get("일주"), obj.get("지지"),
            json.dumps(obj.get("구조분석", []), ensure_ascii=False),
            json.dumps(obj.get("해석", []), ensure_ascii=False),
            obj.get("원문"),
        ))
        if i % log_every == 0:
            log.info("Prepared %d/%d rows", i, len(items))

    with connection() as conn:
        with conn:
            with conn.cursor() as cur:
                psycopg2.extras.execute_values(
                    cur,
                    """
                    INSERT INTO suam_cases_raw(payload, file_hash, row_hash)
                    VALUES %s
                    ON CONFLICT (row_hash) DO NOTHING
                    """,
                    rows_raw, page_size=1000
                )
                psycopg2.extras.execute_values(
                    cur,
                    """
                    INSERT INTO suam_cases(title, ilju, jiji, gujo, haesuk, wonmun)
                    VALUES %s
                    ON CONFLICT (title, wonmun) DO NOTHING
                    """,
                    rows_norm, page_size=1000
                )
                cur.execute("SELECT classify_all(%s);", (None if load_all else len(items),))
    dt = time.perf_counter() - t0
    log.info("Loaded %d items and classified in %.2fs", len(items), dt)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True, help="JSON array file path")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG","INFO","WARNING","ERROR"])
    ap.add_argument("--log-every", type=int, default=1000)
    args = ap.parse_args()
    setup_logging(args.log_level)
    run(args.file, args.limit, args.all, args.log_every)
