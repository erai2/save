import os, json, sqlite3, tempfile
import pandas as pd
import streamlit as st
import networkx as nx
from pyvis.network import Network
import numpy as np

# --- 옵션: OpenAI 임베딩(유사도 검색) ---
USE_AI = True
try:
    import openai
except Exception:
    USE_AI = False

# ------------ 경로/상수 ------------
DB_FILE = "fortune.db"
DEFAULT_JSON = "/mnt/data/suam_cases_parsed_v2.json"  # 업로드하신 파일 경로
TABLE = "case_studies"

# ------------ DB 유틸 ------------
def get_conn():
    return sqlite3.connect(DB_FILE)

def init_db():
    conn = get_conn(); c = conn.cursor()
    c.execute(f"""
    CREATE TABLE IF NOT EXISTS {TABLE} (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        ilju TEXT,
        jiji TEXT,
        structure TEXT,
        interpretation TEXT,
        original TEXT
    )
    """)
    # 임베딩 컬럼(옵션)
    try:
        c.execute(f"ALTER TABLE {TABLE} ADD COLUMN embedding TEXT")
    except Exception:
        pass
    conn.commit(); conn.close()

def db_count():
    conn = get_conn()
    n = conn.execute(f"SELECT COUNT(*) FROM {TABLE}").fetchone()[0]
    conn.close()
    return n

def import_json_to_db(json_path):
    if not os.path.exists(json_path):
        st.warning(f"JSON 파일을 찾을 수 없습니다: {json_path}")
        return 0
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)
    conn = get_conn(); c = conn.cursor()
    inserted = 0
    for case in data:
        title = case.get("title", "")
        ilju = case.get("일주", "")
        jiji = case.get("지지", "")
        structure = case.get("구조분석", [])
        interpretation = case.get("해석", [])
        original = case.get("원문", "")

        if isinstance(structure, list): structure = "\n".join(structure)
        if isinstance(interpretation, list): interpretation = "\n".join(interpretation)

        c.execute(f"""
            INSERT INTO {TABLE} (title, ilju, jiji, structure, interpretation, original)
            VALUES (?,?,?,?,?,?)
        """, (title, ilju, jiji, structure, interpretation, original))
        inserted += 1
    conn.commit(); conn.close()
    return inserted

def fetch_df(keyword=""):
    conn = get_conn()
    if keyword:
        q = f"""
        SELECT id, title, ilju, jiji, structure, interpretation, COALESCE(original,'') as original
        FROM {TABLE}
        WHERE title LIKE ? OR structure LIKE ? OR interpretation LIKE ? OR original LIKE ?
        """
        df = pd.read_sql(q, conn, params=(f"%{keyword}%",)*4)
    else:
        q = f"SELECT id, title, ilju, jiji, structure, interpretation, COALESCE(original,'') as original FROM {TABLE}"
        df = pd.read_sql(q, conn)
    conn.close()
    return df

# ------------ 시각화 ------------
def build_keyword_network(df, keywords, max_cases=50):
    G = nx.Graph()
    # 노드: 사례 제목, 키워드
    for _, row in df.head(max_cases).iterrows():
        title = row["title"] or f"사례 #{row['id']}"
        G.add_node(title, color="#3b82f6", shape="dot")
        text_blob = f"{row.get('structure','')}\n{row.get('interpretation','')}"
        for kw in keywords:
            if kw in text_blob:
                G.add_node(kw, color="#10b981", shape="diamond")
                G.add_edge(title, kw)
    return G

def render_pyvis(G, height="540px"):
    net = Network(height=height, width="100%", bgcolor="#ffffff", font_color="#111")
    net.from_nx(G)
    net.repulsion(node_distance=160, central_gravity=0.2, spring_length=160)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".html") as tmp:
        net.show(tmp.name)
        html = open(tmp.name, "r", encoding="utf-8").read()
    return html

# ------------ AI 유사도 검색(옵션) ------------
def get_openai_client(api_key):
    if not USE_AI:
        return None
    try:
        openai.api_key = api_key
        return openai
    except Exception:
        return None

def embed_text(client, text):
    # 최신 경량 모델 변경 가능: "text-embedding-3-small"
    resp = client.Embeddings.create(model="text-embedding-3-small", input=text[:2000])
    return resp.data[0].embedding

def ensure_embeddings(client):
    if not client:
        return 0
    conn = get_conn(); c = conn.cursor()
    rows = c.execute(f"SELECT id, structure, interpretation FROM {TABLE} WHERE embedding IS NULL").fetchall()
    updated = 0
    for cid, struct, interp in rows:
        blob = (struct or "") + "\n" + (interp or "")
        if not blob.strip(): 
            continue
        try:
            emb = embed_text(client, blob)
            c.execute(f"UPDATE {TABLE} SET embedding=? WHERE id=?", (json.dumps(emb), cid))
            updated += 1
        except Exception as e:
            st.warning(f"임베딩 실패(id={cid}): {e}")
    conn.commit(); conn.close()
    return updated

def cosine(a, b):
    a = np.array(a); b = np.array(b)
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0: return 0.0
    return float(np.dot(a, b) / denom)

def ai_search(client, query, topk=5):
    if not client: 
        return []
    q_emb = embed_text(client, query)
    conn = get_conn()
    rows = conn.execute(f"SELECT id, title, structure, interpretation, embedding FROM {TABLE} WHERE embedding IS NOT NULL").fetchall()
    conn.close()
    scored = []
    for cid, title, struct, interp, emb_json in rows:
        try:
            emb = json.loads(emb_json)
            sim = cosine(q_emb, emb)
            scored.append((sim, cid, title, struct, interp))
        except Exception:
            continue
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:topk]

# ------------ Streamlit UI ------------
st.set_page_config(page_title="수암명리 DB/검색/시각화", layout="wide")
st.title("🟦 수암명리 사례 DB · 검색 · 카드 · 네트워크")

with st.sidebar:
    st.subheader("데이터 소스")
    init_db()
    if st.button("기본 JSON(업로드본) → DB 적재"):
        inserted = import_json_to_db(DEFAULT_JSON)
        st.success(f"기본 JSON에서 {inserted}건 적재 완료")
    uploaded = st.file_uploader("또는 JSON 업로드", type=["json"])
    if uploaded is not None and st.button("업로드 JSON → DB 적재"):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as tmp:
            tmp.write(uploaded.read()); tmp_path = tmp.name
        inserted = import_json_to_db(tmp_path)
        st.success(f"업로드 JSON에서 {inserted}건 적재 완료")

    st.markdown("---")
    st.caption(f"DB 레코드 수: **{db_count()}**")

    st.markdown("---")
    st.subheader("네트워크 키워드")
    default_kws = ["재물", "관인상생", "혼인", "공망", "부동산", "관재", "발재"]
    kw_input = st.text_input("쉼표(,)로 분리", ",".join(default_kws))
    keywords = [k.strip() for k in kw_input.split(",") if k.strip()]

    st.markdown("---")
    use_ai = st.checkbox("AI 유사도 검색(옵션, OpenAI 키 필요)", value=False)
    if use_ai and USE_AI:
        api_key = st.text_input("OpenAI API Key", type="password")
        if api_key:
            client = get_openai_client(api_key)
            if st.button("임베딩 생성/보강"):
                n = ensure_embeddings(client)
                st.success(f"임베딩 {n}건 생성/보강")
    elif use_ai and not USE_AI:
        st.warning("openai 패키지가 설치되어 있지 않습니다. `pip install openai` 후 사용하세요.")
        api_key = None
        client = None
    else:
        api_key = None
        client = None

# 검색 & 카드
col1, col2 = st.columns([2, 1])
with col1:
    keyword = st.text_input("🔎 전체 텍스트 검색 (제목/구조/해석/원문)", "")
    df = fetch_df(keyword)
    st.write(f"검색 결과: **{len(df)}**건")
    for _, row in df.iterrows():
        with st.expander(f"{row['title']}  ·  {row['ilju']}  {row['jiji']}"):
            st.markdown("**구조분석**")
            st.write(row["structure"])
            st.markdown("**해석**")
            st.write(row["interpretation"])
            with st.popover("원문 보기"):
                st.code(row.get("original","") or "", language="text")

    # Export
    st.download_button(
        "현재 결과 CSV 저장",
        df.to_csv(index=False).encode("utf-8-sig"),
        file_name="cases_filtered.csv",
        mime="text/csv"
    )

with col2:
    st.markdown("### 네트워크 시각화")
    if len(df):
        G = build_keyword_network(df, keywords, max_cases=60)
        html = render_pyvis(G)
        st.components.v1.html(html, height=560, scrolling=True)
    else:
        st.info("시각화할 결과가 없습니다.")

# AI 유사도 검색
if use_ai and USE_AI and api_key:
    st.markdown("---")
    st.subheader("🤖 AI 유사도 검색")
    q = st.text_input("질의(예: 관인상생 재물 구조, 부동산 발재 사례 등)", "")
    if q:
        try:
            results = ai_search(get_openai_client(api_key), q, topk=5)
            for sim, cid, title, struct, interp in results:
                st.markdown(f"**[{sim:.3f}] {title}**")
                with st.expander("구조/해석"):
                    st.write(struct or "")
                    st.write(interp or "")
        except Exception as e:
            st.error(f"AI 검색 실패: {e}")

st.markdown("---")
st.caption("✅ 팁: 좌측 사이드바에서 JSON을 DB에 적재한 뒤 검색/시각화하세요.")