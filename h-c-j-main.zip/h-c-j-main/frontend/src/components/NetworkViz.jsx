export default function NetworkViz({ rules }) {
  return (
    <div className="text-gray-600">
      Network visualization is not implemented yet.
    </div>
  );
}
